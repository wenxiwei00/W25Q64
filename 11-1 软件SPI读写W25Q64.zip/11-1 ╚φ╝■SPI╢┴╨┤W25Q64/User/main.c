#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "W25Q64.h"


uint8_t MID;
uint16_t DID;

uint8_t ArrayWrite[] = {0xAA, 0xBB, 0xAF, 0x04}; //数组的定义本来就是取址
uint8_t ArrayRead[4];

int main(void)
{
	/*模块初始化*/
	OLED_Init();		//OLED初始化
	W25Q64_Init();
	W25Q64_ReadID(&MID, &DID); //把两个变量的地址传递进去
	OLED_ShowHexNum(1, 1, MID, 2);
	OLED_ShowHexNum(1, 8, DID, 4);
	
	
	//注意必须擦除才能写入，因为只能1改0，不能0改1.擦除是把所有的位都改成1
	W25Q64_SectorErase(0x000000);//擦除要写sector的起始位地址
	W25Q64_PageProgram(0x0000FF, ArrayWrite, 4);	
	W25Q64_ReadData(0x000000, ArrayRead, 4);//这样跨页写到页的最前面0x000000
	
	OLED_ShowString(2, 1, "W:");
	OLED_ShowHexNum(2, 3, ArrayWrite[0], 2);
	OLED_ShowHexNum(2, 6, ArrayWrite[1], 2);
	OLED_ShowHexNum(2, 9, ArrayWrite[2], 2);
	OLED_ShowHexNum(2, 12, ArrayWrite[3], 2);
	
	
	OLED_ShowString(3, 1, "R:");
	OLED_ShowHexNum(3, 3, ArrayRead[0], 2);
	OLED_ShowHexNum(3, 6, ArrayRead[1], 2);
	OLED_ShowHexNum(3, 9, ArrayRead[2], 2);
	OLED_ShowHexNum(3, 12, ArrayRead[3], 2);	
	
	
	
	
	
	while (1)
	{
		
	}
}
