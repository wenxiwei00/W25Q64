#include "stm32f10x.h"
#include "MySPI.h"
#include "W25Q64_Ins.h"

void W25Q64_Init(void)
{
	MySPI_Init();//只需要初始化SPI就可以了

}


void W25Q64_ReadID(uint8_t *MID, uint16_t *DID)
{
	MySPI_Start();
	MySPI_ReadWriteByte(W25Q64_JEDEC_ID);     //9F是如果读ID的指令
	*MID = MySPI_ReadWriteByte(W25Q64_DUMMY_BYTE);//把FF发给外设，把外设的数据接收回来
	*DID = MySPI_ReadWriteByte(W25Q64_DUMMY_BYTE);//这个地方发什么都不重要，我关注的是读到什么
	*DID <<=8; //看数据手册可知，这个读到的是ID号的高8位
	*DID |= MySPI_ReadWriteByte(W25Q64_DUMMY_BYTE);//这个读到的是ID号低8位，要和前面的8位合并
	
	MySPI_Stop();
}

void W25Q64_WRITEENABLE(void)
{
	MySPI_Start();
	MySPI_ReadWriteByte(W25Q64_WRITE_ENABLE);     
	
	MySPI_Stop();
}

void W25Q64_WaitBusy(void)
{
	uint32_t Timeout = 1000000;
	
	MySPI_Start();
	MySPI_ReadWriteByte(W25Q64_READ_STATUS_REGISTER_1);
	while((MySPI_ReadWriteByte(W25Q64_DUMMY_BYTE) & 0x01) == 0x01) //如果reg1是0x01那么就一直读下去，直到0x00才跳出while
	{
		Timeout --;    //防止我一直在busy，导致程序卡死了
		if (Timeout == 0)
		{
			break;
		}
	}
	MySPI_Stop();
}

//把DataArray的数据写到W25Q64的某个Address里面。写page
//1page=256Bytes
//写数据的时候最多只能写一页数据，如果你想再写，那么就需要再次调用这个函数
//相对于的下面的读数据是可以一直读的，可以跨页
void W25Q64_PageProgram(uint32_t Address, uint8_t *DataArray, uint8_t Count)//写进W25Q64. 
	//地址是24位，但是c语言没有uint24_t
	//2^8=256表示0-255 但是写page的时候page的范围是0--256。所以我们必须要uint16而不能使用uint8。
{
	uint8_t i;
	
	W25Q64_WRITEENABLE();//任何写操作都需要加一个WE
	
	MySPI_Start();
	MySPI_ReadWriteByte(W25Q64_PAGE_PROGRAM);
	MySPI_ReadWriteByte(Address >> 16);
	MySPI_ReadWriteByte(Address >> 8);
	MySPI_ReadWriteByte(Address);
	for (i = 0; i < Count; i ++ )
	{
		MySPI_ReadWriteByte(DataArray[i]);
	}
	
	MySPI_Stop();
	
	W25Q64_WaitBusy();//写操作之后，等到不busy了再跳出这个循环。即由buffer写到flash里面之后我再跳出循环。
}

//sector擦除指令
//1secort = 4KBytes = 4096Bytes
void W25Q64_SectorErase(uint32_t Address)
{
	W25Q64_WRITEENABLE();//任何写操作都需要加一个WE
	
	MySPI_Start();
	MySPI_ReadWriteByte(W25Q64_SECTOR_ERASE_4KB);
	MySPI_ReadWriteByte(Address >> 16);
	MySPI_ReadWriteByte(Address >> 8);
	MySPI_ReadWriteByte(Address);
	 
	MySPI_Stop();
	
	W25Q64_WaitBusy();//写操作之后，等到不busy了再跳出这个循环。
}



//读到MCU的DataArray里面
void W25Q64_ReadData(uint32_t Address, uint8_t *DataArray, uint32_t Count)
{
	uint32_t i;
	MySPI_Start();
	MySPI_ReadWriteByte(W25Q64_READ_DATA);
	MySPI_ReadWriteByte(Address >> 16);
	MySPI_ReadWriteByte(Address >> 8);
	MySPI_ReadWriteByte(Address);
	
	for (i = 0; i < Count; i ++ )
	{
		DataArray[i] = MySPI_ReadWriteByte(W25Q64_DUMMY_BYTE);
	}
	
	MySPI_Stop();
}






