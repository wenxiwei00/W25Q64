#include "stm32f10x.h"

void MySPI_W_SS(uint8_t BitValue)
{
	GPIO_WriteBit(GPIOA, GPIO_Pin_4, (BitAction)BitValue);
}

void MySPI_W_SCK(uint8_t BitValue)
{
	GPIO_WriteBit(GPIOA, GPIO_Pin_5, (BitAction)BitValue);

}

void MySPI_W_MOSI(uint8_t BitValue)
{
	GPIO_WriteBit(GPIOA, GPIO_Pin_7, (BitAction)BitValue);

}

uint8_t MySPI_R_MISO(void)
{
	return GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6);
}


void MySPI_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	MySPI_W_SS(1);//默认为不选择
	MySPI_W_SCK(0);//默认为用模式0
	//MISO，MOSI不需要设置初始
}

//开始传输的时候就是SS变为0，结束传输就是SS变为1
void MySPI_Start(void)
{
	MySPI_W_SS(0);
}


void MySPI_Stop(void)
{
	MySPI_W_SS(1);
}

//用掩码方式实现软件SPI
//SPI MODE0 上升沿移到寄存器里面，下降沿移出到线上
uint8_t MySPI_ReadWriteByte(uint8_t ByteSend)//要发送8位的数据
{
	//从MISO上面接到的数据
	uint8_t i, ByteReceive = 0x00;
	
	for (i = 0; i < 8; i ++)
	{
		//把Master的寄存器上的最高位（最左边）移动到MOSI线上面
		//比如要传的数据是0x1010 1011
		//那么0x1010 1011&0x80==0x80
		//GPIO_WriteBit(GPIOA, GPIO_Pin_7, (BitAction)BitValue);
		//上面代码的逻辑是只要BitValue不是0，我就把这个GPIO口拉高
		MySPI_W_MOSI(ByteSend & (0x80 >> i));
		
		//SCK上升沿
		MySPI_W_SCK(1);
		
		//把MISO上的数据读到master的移位寄存器上
		//读到的数据放在最高位置（最左边）
		//从机 会把MOSI的数据读走，不用我们管
		//我们只要控制主机，把MISO上面的数据读走
		if (MySPI_R_MISO() == 1){ByteReceive |= (0x80 >> i);}//如果是读到的是1，那么ByteReceive=ByteReceive|0x80
		
		//SCK产生下降沿 继续把下一位移出
		MySPI_W_SCK(0);
	}
	
	return ByteReceive;
}















