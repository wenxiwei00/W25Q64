#ifndef _MYSPI_H
#define _MYSPI_H



void MySPI_Init(void);
void MySPI_Start(void);
void MySPI_Stop(void);
uint8_t MySPI_ReadWriteByte(uint8_t ByteSend);





#endif